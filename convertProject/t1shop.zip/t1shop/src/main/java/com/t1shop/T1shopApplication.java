package com.t1shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T1shopApplication {

	public static void main(String[] args) {
		SpringApplication.run(T1shopApplication.class, args);
	}

}
