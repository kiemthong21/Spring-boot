package com.t1shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T1shopApplicationTests {

	@Test
	void contextLoads() {
	}

}
